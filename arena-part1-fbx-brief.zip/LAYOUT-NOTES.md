# Real-world layout — Texaco ShortStop, 1185 Interstate 35 N, New Braunfels TX

Researched 2026-10-28 via Google Maps satellite (19–21z) + Street View (Apr 2026, 1189 S I-35
South Frontage Rd) + Maps business photos (Sep 2018, May 2025). Anchor = the lot, not compass:
store on the far (west) side from I-35; canopy between store and frontage road; storefront
faces EAST toward canopy/road. I-35 runs NE–SW on the east side; Loop 337 (TX-337) crosses
at the lot's NE corner.

## Store
- Single-storey rectangle, west/back of lot, longer N-S than wide E-W. Flat light grey/white
  roof with several small rooftop HVAC units. Light grey/white walls.
- East (canopy-facing) side: large glass windows/doors, red horizontal band at top of wall,
  green "ATM" sign. No awning identified. NO legible "SHORT STOP" lettering seen on the
  building in these views (not confirmed ≠ absent in real life).

## Canopy
- East of store, long thin flat slab, long axis N-S parallel to frontage road, ~2.5–3× as long
  as wide, about as long as the store. CURRENT scheme (2025–26): red fascia with white TEXACO
  letters on the long side, dark/black top edge, light tan/cream underside with recessed
  lights, light grey/blue-grey columns. (2018 photos show an older dark blue/black fascia.)
- Pump islands: single row along the canopy length, dispensers on both sides, red/white
  dispenser tops; pump numbers seen include 12, 14, 16. 4 islands = confirmed minimum.
- Diesel sold under main canopy (green Diesel price panel); no separate diesel canopy.

## Pylon signs (TWO)
- Tall red TWIN-POST signs, ~2–3× canopy height, on the grass strip at the frontage edge:
  one SE corner, one NE corner (near Loop 337). Top panel white with red Texaco star in a
  circle; below, a dark price board (white/green digits — Apr 2026 read ~3.79 / 3.99 /
  Diesel 5.19⁹⁄₁₀, layout reference only, prices change); bottom red panel "Car Wash".

## Lot
- Wedge/triangular, wider at north, narrowing south; concrete, faded white parking lines,
  one blue accessible bay. Parking row along store's east side + bays south of store.
- Entrances: south drive from frontage road; north drive to Loop 337 junction; curved west
  access shared with Edelweiss Inn parking.
- Sidewalk/curb + narrow patchy grass strip along frontage; signalised crosswalk at Loop 337.
- Small dark-roofed enclosure south of store (dumpster/utility, uncertain). Car wash exists
  (pylon + reviews) but no large wash-tunnel building resolved — do not model one.

## Surroundings
- East: S I-35 South Frontage Rd (multi-lane), then I-35 main lanes on embankment/overpass SE;
  brick-paved signalised Loop 337 intersection at NE corner.
- West/SW: Edelweiss Inn — long Tudor-style building, steep dark-green roof, white timber
  framing; large mature trees behind store / around the inn.
- North across Loop 337: McDonald's (brown/grey, tall golden-arches sign); further NW the
  New Braunfels Square shopping area. South: open grass + I-35 on-ramp curve.
- NO Wendy's adjacent to this lot in current satellite/Street View (nearest Wendy's listing:
  143 TX-46). The Facebook cover photo's Wendy's is NOT the immediate neighbour — earlier
  builds' assumption corrected 2026-10-28.
