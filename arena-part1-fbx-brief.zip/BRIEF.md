# Texaco ShortStop — rebuild brief (read this first)

Business: Texaco ShortStop (Texaco Short Stop), 1185 Interstate 35 N, New Braunfels, TX 78130.
Phone (830) 606-1892. Hours: Mon–Fri 5 AM–12 AM, Sat 5 AM–1 AM, Sun 6 AM–12 AM.
Domain: shortstop35.store (NO hyphen — the hyphenated spelling is wrong, do not use it).
Fuel: Texaco with Techron. This is a REAL location — rebuild it accurately, do not invent a generic station.

## Files in this pack
- `station/4002336.FBX` + `station/Maps/*.jpg` — the licensed station model and its 13 texture maps (convert FBX to GLB for web).
- `pump/pump.obj` + `pump/pumptex/*.png` — photoreal dispenser model (display plinth already removed) with full PBR sets: body_*, handle_*, panel_* (albedo, normal, roughness, metalness, AO; panel also emissive). Real dispenser height 1.9 m — scale to that. Instance at every fueling position.
- `references/` — photos: the station model's clay render (structure), a real Texaco pump island (branding: red/white "with TECHRON" header, star logos, red bollards), a real Texaco canopy/store exterior (red fascia, white TEXACO letters, star roundel).
- `concrete.jpg` — weathered concrete photo texture from the model pack; use it on the lot (the flat procedural ground is the #1 quality killer).
- `LAYOUT-NOTES.md` — the researched ground truth for the lot (satellite + Street View). Follow it over any generic assumption.

## The real layout (summary — full detail in LAYOUT-NOTES.md)
- Store: west/back of lot, single-storey, longer N-S, flat light roof + rooftop HVAC, light walls; east face = glass storefront + red horizontal band + green ATM sign. Storefront faces EAST.
- Canopy: between store and frontage road; long thin slab, axis N-S, ~2.5–3x as long as wide; CURRENT scheme: red fascia with white TEXACO letters, dark top edge, cream underside with recessed lights, blue-grey columns.
- Pumps: ONE single row of 4 islands along the canopy, dispensers both sides, numbers up to 16, diesel under the main canopy (no separate diesel canopy).
- TWO tall red twin-post pylon signs (SE corner + NE corner at Loop 337): white top panel with red Texaco star, dark price board below, red "Car Wash" panel at the bottom.
- Lot: wedge-shaped concrete (wider north), parking along the store's east side + south bays, one accessible bay; entrances south (frontage) and north (Loop 337).
- Surroundings: frontage road + I-35 main lanes east; brick-paved signalised Loop 337 junction NE with crosswalk; Edelweiss Inn behind/west (Tudor, steep dark-green roof, white timber framing) + mature trees; McDonald's across Loop 337 north. NO Wendy's next door — do not add one. No car-wash tunnel building.

## Quality requirements (the previous build failed on these)
- Use the supplied models and PBR/photo textures — no procedural placeholder geometry for pumps, store, or canopy.
- Renderer: setPixelRatio(min(devicePixelRatio, 2)), ACES tone mapping, PCF soft shadows, anisotropy 8 on textures.
- The 3D scene must be fully visible on load at phone widths too: any title panel is a small dismissible chip; info cards open only on marker tap (bottom sheet on mobile); nothing auto-opens.
- Day / golden / night modes; night = lit canopy panels, glowing signs, emissive pump screens, headlights.
- Verify before claiming done: render screenshots (desktop overview, mobile overview, pumps close-up, night) and show them.
